//
//  ViewController.swift
//  LocationApp
//
//  Created by Samuel Gallego Rivera on 6/03/25.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    
    @IBOutlet weak var map: MKMapView!
    
    let locationManager = CLLocationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        print(error)
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        checkAndStart()
    }
    
    var pin:MKPointAnnotation? = nil
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print(locations)
        
        if let location = locations.first{
            
            let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
            
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
            
            map.setRegion(region, animated: true)
            
            if let pin = pin{
                pin.coordinate = center
                CLGeocoder().reverseGeocodeLocation(location) {
                    (placemarks, error)->Void in
                    
                    if let e = error{
                        print(e)
                        return
                    }
                    
                    if let placemarks = placemarks{
                        if let mark = placemarks.first{
                            let title = "\(mark.name ?? "-")\n\(mark.locality ?? "-")"
                            self.pin?.title = title

                        }
                    }
                    
                }
                
            }else{
                pin = MKPointAnnotation()
                pin?.coordinate = center
                pin?.title = "My Location"
                map.addAnnotation(pin!)
            }
        }
    }
    
    func checkAndStart(){
        
        switch locationManager.authorizationStatus{
        case .authorizedAlways:
            print("Always authorization granted")
            locationManager.startUpdatingLocation()
        case .authorizedWhenInUse:
            print("When in use, authorization granted")
            locationManager.startUpdatingLocation()
        case .denied, .restricted:
            print("Sorry, no authorization granted")
        default:
            print("We dont know, lets ask!")
            locationManager.requestAlwaysAuthorization()
        }
    }
    

    @IBAction func startLocation(_ sender: Any){
        checkAndStart()
    }
    
    
    @IBAction func stopLocation(_ sender: Any){
        locationManager.stopUpdatingLocation()
        
    }
    
    
    
    
    

}

