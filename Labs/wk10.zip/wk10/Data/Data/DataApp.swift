//
//  DataApp.swift
//  Data
//
//  Created by Samuel Gallego Rivera on 13/03/25.
//

import SwiftUI

@main
struct DataApp: App {
    
    @StateObject private var dataController = DataController()
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, dataController.container.viewContext)
        }
    }
}
