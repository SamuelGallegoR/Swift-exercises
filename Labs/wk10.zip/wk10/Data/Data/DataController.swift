//
//  DataController.swift
//  Data
//
//  Created by Samuel Gallego Rivera on 13/03/25.
//

import Foundation
import CoreData

class DataController:ObservableObject{
    let container = NSPersistentContainer(name: "myData")
    
    init(){
        container.loadPersistentStores{
            description, error in
            if let error = error{
                print("Core data failed to load: \(error.localizedDescription)")
            }
        }
    }
    
    
}
