//
//  ContentView.swift
//  Data
//
//  Created by Samuel Gallego Rivera on 13/03/25.
//

import SwiftUI

class RandomGen{
    
    static func userName() -> String {
        
        let names = ["Aaran", "Aaren", "Aarez", "Aarman", "Aaron", "Aaron-James", "Aarron", "Aaryan", "Aaryn", "Aayan", "Aazaan", "Abaan", "Abbas", "Abdallah", "Abdalroof", "Abdihakim", "Abdirahman", "Abdisalam", "Abdul", "Abdul-Aziz", "Abdulbasir", "Abdulkadir", "Abdulkarem", "Abdulkhader", "Abdullah", "Abdul-Majeed", "Abdulmalik", "Abdul-Rehman", "Abdur", "Abdurraheem", "Abdur-Rahman", "Abdur-Rehmaan", "Abel", "Abhinav", "Abhisumant", "Abid", "Abir", "Abraham", "Abu", "Abubakar", "Ace", "Adain", "Adam", "Adam-James", "Addison", "Addisson", "Adegbola", "Adegbolahan", "Aden", "Adenn", "Adie", "Adil", "Aditya", "Adnan", "Adrian", "Adrien", "Aedan", "Aedin", "Aedyn", "Aeron", "Afonso", "Ahmad", "Ahmed", "Ahmed-Aziz", "Ahoua", "Ahtasham", "Aiadan", "Aidan", "Aiden", "Aiden-Jack", "Aiden-Vee", "Aidian", "Aidy", "Ailin", "Aiman", "Ainsley", "Ainslie", "Airen", "Airidas", "Airlie", "AJ", "Ajay", "A-Jay", "Ajayraj", "Akan", "Akram", "Al", "Ala", "Alan"]
        
        let id1 = Int.random(in: 0 ..< names.count)
        let id2 = Int.random(in: 0 ..< names.count)
        
        return "\(names[id1]) \(names[id2])"
    }
    
}

struct ContentView: View {
    @Environment(\.managedObjectContext)
    var context
    
    @FetchRequest(sortDescriptors: [])
    var users:FetchedResults<User>
    
    @FetchRequest(sortDescriptors: [NSSortDescriptor(key: "author.userName", ascending: true)])
    var posts:FetchedResults<Post>
    
    var body: some View {
        VStack {
            Button(action: {
                let user = User(context: context)
                user.userName = RandomGen.userName()
                try? context.save()
                
            }, label: {Text("Add User!")})
            
            List{
                ForEach(users, id:\.self){
                    user in
                    HStack{
                        Text(user.userName ?? "-")
                            .onTapGesture {
                                let post = Post(context: context)
                                post.author = user
                                post.title = "New post from user\(posts.count)"
                                try? context.save()
                            }
                        Text("\(user.posts?.count ?? 0)")
                    }
                }.onDelete(perform: {
                    offsets in
                    context.delete(users[offsets.first ?? 0])
                    try? context.save()
                })
            }
            
            Text("Posts:")
            List{
                ForEach(posts, id:\.self){
                    p in
                    HStack{
                        Text(p.title ?? "-")
                        Text(p.author?.userName ?? "-")
                    }
                }.onDelete(perform:{
                    offsets in
                    context.delete(posts[offsets.first ?? 0])
                })
            }
        }
        .padding()
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
