//
//  ContentView.swift
//  newprojectweek10
//
//  Created by Samuel Gallego Rivera on 20/03/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var nm = NetworkManager() //This is observable
    @State var id: Int = 1
    @State var task : ToDo? = nil
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            
            TextField("ID:", value: $id, formatter: NumberFormatter())
            Button("Get Task", action: {
                nm.fetchAllTasks(with: id, completionHandler: {
                    t in
                    self.task = t
                })
            })
            
            Text(task?.title ?? "-----")
            List(nm.tasks){
                t in
                Text(t.title)
                    .listRowBackground(t.completed ? Color.green : Color.red)
            }.onAppear{
                nm.fetchAllTasks(completionHandler: {
                    tasks in
                    print("recieved \(tasks.count) tasks")
                })
            }
            
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
