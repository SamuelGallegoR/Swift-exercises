//
//  newprojectweek10App.swift
//  newprojectweek10
//
//  Created by Samuel Gallego Rivera on 20/03/25.
//

import SwiftUI

@main
struct newprojectweek10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
