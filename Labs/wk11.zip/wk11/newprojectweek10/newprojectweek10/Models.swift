//
//  Models.swift
//  newprojectweek10
//
//  Created by Samuel Gallego Rivera on 20/03/25.
//

import Foundation

struct ToDo: Codable, Identifiable{
    let userId:Int
    let id:Int
    let title:String
    let completed:Bool
    
    
    
}
